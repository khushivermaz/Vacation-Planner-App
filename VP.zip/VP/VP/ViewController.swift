//
//  ViewController.swift
//  VP
//
//  Created by Student on 14/04/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var image: UIImageView!
    
}

